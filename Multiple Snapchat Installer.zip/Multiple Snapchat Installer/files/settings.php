<div class="showPixelCode">
	<table id="showPixel">
		<thead>
			<tr>
				<th>Pixel</th>
				<th>Operations</th>
			</tr>
		</thead>
		<tbody class="editPixelCode"></tbody>
		<!--tfoot>
			<tr>
				<td></td>
				<td>
					
				</td>
			</tr>
		</tfoot-->
	</table>
	<div class="buttons-pixel">
			<input class="btn btn-default" id="addNewPixel" value="New Pixel" type="button">
			<input class="btn btn-default" id="saveEditPixel" value="Save" type="button">
	</div>
</div>