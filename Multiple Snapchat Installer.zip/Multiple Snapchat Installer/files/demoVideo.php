<div class="video-instruction-main" style="text-align: center;">
	<a href="https://www.youtube.com/embed/9X23hucOWj8?autoplay=1&amp;rel=0&amp;showinfo=0" target="_blank"><img src="../images/ytVideo.jpg" style="width:100%;cursor:pointer;" id="ytVideo_thumb" class="ytVideo_thumb" alt="Video" /></a>
	<iframe id="video-instruction-iframe-main" frameborder="0" style="display:none;" allowfullscreen="1" allow="autoplay; encrypted-media" title="YouTube video player" width="728" height="410" src="https://www.youtube.com/embed/Nkg5yGdB_Gw?autoplay=0&amp;rel=0&amp;showinfo=0"></iframe>
	<div id="video-instruction-iframe-main" style="display:none;"></div>
</div>

