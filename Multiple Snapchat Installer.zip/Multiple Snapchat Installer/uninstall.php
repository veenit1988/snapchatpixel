<?php
require __DIR__.'/connect.php'; //Database
$data = file_get_contents('php://input');
mail('samriti.3ginfo@gmail.com','APP DELETE',$data);
if($data) {
	$shopData = json_decode($data);	
	$sql = "UPDATE PixelInstaller SET active=0 WHERE shop_url='".$shopData->domain."'";
	//$sql = "DELETE FROM PixelInstaller WHERE shop_url='".$shopData->domain."'";
	$result = mysqli_query($con, $sql);
}
?>