<?php
require __DIR__.'/conf.php'; //Configuration
require __DIR__.'/vendor/autoload.php';
use phpish\shopify;
$access_token = $_REQUEST['access_token'];
$shopify = shopify\client($_REQUEST['shop'], SHOPIFY_APP_API_KEY, $access_token );
try
{	
	$pagelimit = 250;
	$countMetafields = $shopify('GET /admin/metafields/count.json');
	$page = ceil($countMetafields/$pagelimit);
	$j = 1;
	for($i=1;$i<=$page;$i++) {
		$response = $shopify("GET /admin/metafields.json?limit=$pagelimit&page=$i");
		if($response) {
			foreach($response as $options){
				if($options['namespace'] == "MultiSnapchatCode"){
					$getArray[$j] = $options['value'];				
					$j++;
				}
			}		
		}
	}
	if(isset($getArray)) {
		echo json_encode($getArray);
	}
}
catch (shopify\ApiException $e)
{	
	# HTTP status code was >= 400 or response contained the key 'errors'
	echo $e;
	print_r($e->getRequest());
	print_r($e->getResponse());
}
?>
