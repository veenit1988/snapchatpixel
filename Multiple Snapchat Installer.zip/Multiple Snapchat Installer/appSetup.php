<?php
session_start();
// Required File Start.........
require __DIR__.'/conf.php'; //Configuration
require __DIR__.'/connect.php'; //Database
require __DIR__.'/vendor/autoload.php';
use phpish\shopify;
// Required File END...........
error_reporting(E_ALL); 
ini_set('display_errors', 1);
if((isset($_REQUEST['shop'])) && (isset($_REQUEST['code'])) && $_REQUEST['shop']!='' && $_REQUEST['code']!='' )
{	
	$shop = $_REQUEST['shop'];
	$code = $_REQUEST['code'];
	$hmac = $_REQUEST['hmac'];
	
	$sql1 = "SELECT * FROM PixelInstaller WHERE shop_url='$shop' AND active=1";
	$resData = mysqli_query($con, $sql1);
	if(mysqli_num_rows($resData) > 0){
		//redirect to dashboard
		header('location:dashboard.php?shop='.$shop.'&code='.$code.'&hmac='.$hmac.'&appUrl='.APP_SERVER_URL);
	} else {
		$testSql = "SELECT * FROM PixelInstaller WHERE shop_url='$shop'";
		$testResData = mysqli_query($con, $testSql);
		if(mysqli_num_rows($testResData) > 0){
			if(isset($_COOKIE['delineCharge']) == 'delineCharge') {
				setcookie('delineCharge', '', time() - 86300);
				include_once('declineCharge.php');
			} else {
				//redirect to appSetup.php
				$sql = "DELETE FROM PixelInstaller WHERE shop_url='$shop'";
				mysqli_query($con, $sql);
				$access_token = shopify\access_token($shop, SHOPIFY_APP_API_KEY, SHOPIFY_APP_SHARED_SECRET, $_REQUEST['code']);
				if($access_token) {
					include_once('ShopOwnerData.php');
					if(SHOPIFY_APP_PRICE == '0.00') {
						$sql2 = "INSERT INTO PixelInstaller (access_token, shop_url, charge_id, active) VALUES ('".$access_token."', '".$shop."', '0', '1')";
						$insert = mysqli_query($con, $sql2);
						if($insert == 1 ) {
							setcookie('showVideo', 'showVideo', time() + 86300, "/");
							$shopUrl = "https://$shop/admin/apps/".SHOPIFY_APP_HANDLE;
							echo "<script> window.location.href='$shopUrl'</script>";
						} else {
							echo 'Unable to add shop to database.  The application has not been installed';
						}
					} else {
						$sql2 = "INSERT INTO PixelInstaller (access_token, shop_url, charge_id, active) VALUES ('".$access_token."', '".$shop."', '', '')";
						$insert = mysqli_query($con, $sql2);
						if($insert == 1 ) {
							setcookie('showVideo', 'showVideo', time() + 86300, "/");
							include_once('recurringPayment-noTrial.php');
						} else {
							echo 'Unable to add shop to database.  The application has not been installed';
						}
					}
				} else {
					echo 'Unable to get access token.  The application has not been installed.';
				}
			}
		} else {
			$access_token = shopify\access_token($shop, SHOPIFY_APP_API_KEY, SHOPIFY_APP_SHARED_SECRET, $_REQUEST['code']);
			if($access_token) {
				include_once('ShopOwnerData.php');
				if(SHOPIFY_APP_PRICE == '0.00') {
					$sql2 = "INSERT INTO PixelInstaller (access_token, shop_url, charge_id, active) VALUES ('".$access_token."', '".$shop."', '0', '1')";
					$insert = mysqli_query($con, $sql2);
					if($insert == 1 ) {
						setcookie('showVideo', 'showVideo', time() + 86300, "/");
						$shopUrl = "https://$shop/admin/apps/".SHOPIFY_APP_HANDLE;
						echo "<script> window.location.href='$shopUrl'</script>";
					} else {
						echo 'Unable to add shop to database.  The application has not been installed';
					}
				} else {
					$sql2 = "INSERT INTO PixelInstaller (access_token, shop_url, charge_id, active) VALUES ('".$access_token."', '".$shop."', '', '')";
					$insert = mysqli_query($con, $sql2);
					if($insert == 1 ) {
						setcookie('showVideo', 'showVideo', time() + 86300, "/");
						include_once('recurringPayment.php');
					} else {
						echo 'Unable to add shop to database.  The application has not been installed';
					}
				}
			} else {
				echo 'Unable to get access token.  The application has not been installed.';
			}
		}
	}
} else {
	echo 'The application has not been installed.';
}
?>