<?php
header("Access-Control-Allow-Origin: *");
require __DIR__.'/conf.php'; //Configuration
require __DIR__.'/vendor/autoload.php';
use phpish\shopify;
$access_token = $_REQUEST['access_token'];
$name = $_REQUEST['firstname'].' '.$_REQUEST['lastname'];
$email = $_REQUEST['email'];
$query = $_REQUEST['query'];
$shopify = shopify\client($_REQUEST['shop'], SHOPIFY_APP_API_KEY, $access_token );
try
{	
	// To send HTML mail, the Content-type header must be set
	$headers  = 'MIME-Version: 1.0'."\r\n";
	$headers = 'Content-type: text/html;'."\r\n";
	
	// Compose a simple HTML email message
	$message = '<html><body>';
	$message .= "<p>Name: $name</p>";
	$message .= "<p>Email: $email</p>";
	$message .= "<p>$query</p>";
	$message .= '</body></html>';

	if(mail(EMAIL_TO,EMAIL_SUBJECT,$message,$headers)) {
		echo 'Sent';
	} else {
		echo 'Not';
	}
}
catch (shopify\ApiException $e)
{
	# HTTP status code was >= 400 or response contained the key 'errors'
	echo $e;
	print_r($e->getRequest());
	print_r($e->getResponse());
}
?>