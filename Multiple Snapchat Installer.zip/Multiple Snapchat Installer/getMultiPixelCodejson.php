<?php
require __DIR__.'/conf.php'; //Configuration
require __DIR__.'/vendor/autoload.php';
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Credentials: FALSE');
use phpish\shopify;
if(isset($_REQUEST['access_token']) && isset($_REQUEST['shop'])) {
	$access_token = $_REQUEST['access_token'];
	$shopify = shopify\client($_REQUEST['shop'], SHOPIFY_APP_API_KEY, $access_token );
	try
	{	
		$pagelimit = 250;
		$countMetafields = $shopify('GET /admin/metafields/count.json');
		$shop_response = $shopify('GET /admin/shop.json');
		$page = ceil($countMetafields/$pagelimit);
		$Array = array();
		$j = 1;
		for($i=1;$i<=$page;$i++) {
			$meta_response = $shopify("GET /admin/metafields.json?limit=$pagelimit&page=$i");
			foreach($meta_response as $options) {	
				if($options['namespace'] == "MultiSnapchatCode") {		
					$getArray[$j] = $options['value'];
					$j++;
				}
			}
		}
		if(isset($getArray)) {	
			$Array['pixelCode'] = $getArray;
			//$Array['Email'] = $shop_response['email'];
			$Array['Currency'] = $shop_response['currency'];
			echo json_encode($Array);
		}
	}
	catch (shopify\ApiException $e)
	{
		# HTTP status code was >= 400 or response contained the key 'errors'
		echo $e;
		print_r($e->getRequest());
		print_r($e->getResponse());
	}
}
?>