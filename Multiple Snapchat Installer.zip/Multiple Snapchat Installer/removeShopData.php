<?php
require __DIR__.'/connect.php'; //Database
if(isset($_REQUEST['shop'])) {
	$sql = "DELETE FROM PixelInstaller WHERE shop_url='".$_REQUEST['shop']."'";
	$result = mysqli_query($con, $sql);
}
?>