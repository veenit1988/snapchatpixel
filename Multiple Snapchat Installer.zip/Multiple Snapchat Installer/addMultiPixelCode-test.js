var length = document.getElementsByTagName("script").length;
for(var i = 0; i < length; i++) {	
	if(document.getElementsByTagName("script")[i].hasAttribute("src") ) {
		if(document.getElementsByTagName("script")[i].getAttribute("src").indexOf('snapmultipixel.website/addMultiPixelCode-test.js') > -1) {
			var pageURL = window.location.href;
			var getData = document.getElementsByTagName("script")[i].getAttribute("src");
			var data = getData.split('?')[1];
			var multiPixServer = data.split('&')[1].split('server=')[1];
			//CART PAGE
			if(pageURL.indexOf('cart') > -1) {
				$.ajax({
					url: multiPixServer+"getMultiPixelCodejson.php?"+data,
					type: 'GET',
					dataType: "json",
					header: {
						"Access-Control-Allow-Origin": "*"
					},
					success: function(response) {
						if(response['pixelCode']) {
							var user_email = '';
							if($('meta[name=pixelCode_customer_email]').length) {
								user_email = $('meta[name=pixelCode_customer_email]').attr("content");
							}
							var pixelCode = response['pixelCode'];
							var currency = response['Currency'];
							var showPixel = '';
							$.each( pixelCode, function(index,value) {
								showPixel += "snaptr('init','"+value+"',{'user_email':'"+user_email+"'});";
							});
							if(showPixel != '') {
								$('head').append("<script type='text/javascript'>(function(win, doc, sdk_url){if(win.snaptr) return;var tr=win.snaptr=function(){tr.handleRequest? tr.handleRequest.apply(tr, arguments):tr.queue.push(arguments);}; tr.queue = [];var s='script';var new_script_section=doc.createElement(s);new_script_section.async=!0;new_script_section.src=sdk_url;var insert_pos=doc.getElementsByTagName(s)[0];insert_pos.parentNode.insertBefore(new_script_section, insert_pos);})(window, document, 'https://sc-static.net/scevent.min.js');"+showPixel+"snaptr('track', 'START_CHECKOUT');</script>");
							}
						}
					}
				});
			}
			//PRODUCT PAGE
			else if(pageURL.indexOf('/products/') > -1) {
				if (pageURL.indexOf('?variant=') > -1) {
					var product_url = pageURL.split('?variant=');
					product_url = product_url[0] + '.json';
				} else {
					var product_url = pageURL + '.json';
				}
				
				$.ajax({
					url: multiPixServer+"getMultiPixelCodejson.php?"+data,
					type: 'GET',
					dataType: "json",
					header: {
						"Access-Control-Allow-Origin": "*"
					},
					success: function(response) {
						if(response['pixelCode']) {
							var user_email = '';
							if($('meta[name=pixelCode_customer_email]').length) {
								user_email = $('meta[name=pixelCode_customer_email]').attr("content");
							}
							var pixelCode = response['pixelCode'];
							var currency = response['Currency'];
							var showPixel = '';
							var showAddtoCartPixel = '';
							$.each( pixelCode, function(index,value) {
								showPixel += "snaptr('init','"+value+"',{'user_email':'"+user_email+"'});";
							});
							// On Add to cart click
							$.ajax({
								url: product_url,
								dataType: "jsonp",
								header: {
									"Access-Control-Allow-Origin": "*"
								},
								success: function(responseData) {
									var product = responseData.product;
									$('form[action="/cart/add"] [type="submit"]').click(function(){
										var variantid = $('select[name="id"]').val();
										$.each(product.variants, function(index){
											if(product.variants[index].id == variantid){
												var price = product.variants[index].price;
												showAddtoCartPixel += "snaptr('track', 'ADD_CART', {'currency': '"+currency+"', 'price': "+price+" });</script>";
											}
										});
										if(showAddtoCartPixel != '') {
											$('head').append("<script type='text/javascript'>(function(win, doc, sdk_url){if(win.snaptr) return;var tr=win.snaptr=function(){tr.handleRequest? tr.handleRequest.apply(tr, arguments):tr.queue.push(arguments);}; tr.queue = [];var s='script';var new_script_section=doc.createElement(s); new_script_section.async=!0;new_script_section.src=sdk_url;var insert_pos=doc.getElementsByTagName(s)[0]; insert_pos.parentNode.insertBefore(new_script_section, insert_pos);})(window, document, 'https://sc-static.net/scevent.min.js');"+showPixel+''+showAddtoCartPixel+"</script>");
										}
									});
								}
							});
							if(showPixel != '') {
								$('head').append("<script type='text/javascript'>(function(win, doc, sdk_url){if(win.snaptr) return;var tr=win.snaptr=function(){tr.handleRequest? tr.handleRequest.apply(tr, arguments):tr.queue.push(arguments);}; tr.queue = [];var s='script';var new_script_section=doc.createElement(s);new_script_section.async=!0;new_script_section.src=sdk_url;var insert_pos=doc.getElementsByTagName(s)[0];insert_pos.parentNode.insertBefore(new_script_section, insert_pos);})(window, document, 'https://sc-static.net/scevent.min.js');"+showPixel+"snaptr('track','PAGE_VIEW');</script>");
							}
						}	
					}
				});
			}
			//THANKYOU PAGE
			else if(pageURL.indexOf('/thank_you') > -1 ) {
				if(document.head.innerHTML.indexOf('Shopify.checkout')){
					var CheckoutData = document.head.innerHTML.split('Shopify.checkout')[1].split('</script>')[0].replace('=','');
					CheckoutData = JSON.parse(CheckoutData.replace(';',''));
				}
				function createCORSRequest(method, url){
					var xhr = new XMLHttpRequest();
					if ("withCredentials" in xhr){
						xhr.open(method, url, true);
					} else if (typeof XDomainRequest != "undefined"){
						xhr = new XDomainRequest();
						xhr.open(method, url);
					} else {
						xhr = null;
					}
					return xhr;
				}
				var request = createCORSRequest("GET", multiPixServer+"getMultiPixelCodejson.php?"+data);
				if (request){
					request.onload = function(){
						var price = document.getElementsByClassName('payment-due__price')[0].innerText;
						if(request.responseText) {
							var response = JSON.parse(request.responseText);
							if(response['pixelCode']) {
								var pixelCode = response['pixelCode'];
								var currency = response['Currency'];
								var pixelLen = Object.keys(pixelCode).length;
								var showPixel = '';
								for(var i=1; i<= pixelLen; i++) {
									showPixel += "snaptr('init','"+pixelCode[i]+"',{'user_email':'"+CheckoutData.email+"'});";
									if(i === pixelLen) {
										var script = document.createElement("script");
										script.type = "text/javascript";
										script.innerHTML = "(function(win, doc, sdk_url){if(win.snaptr) return;var tr=win.snaptr=function(){tr.handleRequest? tr.handleRequest.apply(tr, arguments):tr.queue.push(arguments);}; tr.queue = [];var s='script';var new_script_section=doc.createElement(s);new_script_section.async=!0;new_script_section.src=sdk_url;var insert_pos=doc.getElementsByTagName(s)[0];insert_pos.parentNode.insertBefore(new_script_section, insert_pos);})(window, document, 'https://sc-static.net/scevent.min.js');"+showPixel+"snaptr('track', 'PURCHASE', {'currency': '"+currency+"', 'price': "+CheckoutData.total_price+" });";
										document.head.appendChild(script);
									}
								}
							}
						}
					};
					request.send();
				}
			}
			//OTHER PAGE
			else {
				$.ajax({
					url: multiPixServer+"getMultiPixelCodejson.php?"+data,
					type: 'GET',
					dataType: "json",
					header: {
						"Access-Control-Allow-Origin": "*"
					},
					success: function(response) {
						if(response['pixelCode']) {
							var user_email = '';
							if($('meta[name=pixelCode_customer_email]').length) {
								user_email = $('meta[name=pixelCode_customer_email]').attr("content");
							}
							var pixelCode = response['pixelCode'];
							var currency = response['Currency'];
							var showPixel = '';
							var showAddtoCartPixel = '';
							$.each( pixelCode, function(index,value) {
								showPixel += "snaptr('init','"+value+"',{'user_email':'"+user_email+"'});";
							});
							if(showPixel != '') {
								$('head').append("<script type='text/javascript'>(function(win, doc, sdk_url){if(win.snaptr) return;var tr=win.snaptr=function(){tr.handleRequest? tr.handleRequest.apply(tr, arguments):tr.queue.push(arguments);}; tr.queue = [];var s='script';var new_script_section=doc.createElement(s);new_script_section.async=!0;new_script_section.src=sdk_url;var insert_pos=doc.getElementsByTagName(s)[0];insert_pos.parentNode.insertBefore(new_script_section, insert_pos);})(window, document, 'https://sc-static.net/scevent.min.js');"+showPixel+"snaptr('track','PAGE_VIEW');</script>");
							}
						}	
					}
				});
			}
		}
	}	
}
/************************Smriti Bakshi******************************/