<?php
if (!isset($_SESSION)) session_start();
// Required File Start.........
require __DIR__.'/conf.php'; //Configuration
require __DIR__.'/connect.php'; //Database
require __DIR__.'/vendor/autoload.php';
use phpish\shopify;
// Required File END...........
error_reporting(E_ALL); 
ini_set('display_errors', 1);
if((isset($_REQUEST['shop'])) && $_REQUEST['shop']!='' )
{	
	$shop = $_REQUEST['shop'];
	$code = $_REQUEST['code'];
	$hmac = $_REQUEST['hmac'];
	$appurl = $_REQUEST['appUrl'];
	
	$sql = "SELECT * FROM PixelInstaller WHERE shop_url='$shop'";
	$result = mysqli_query($con, $sql);
	if(mysqli_num_rows($result) > 0){
		$row = mysqli_fetch_assoc($result);
		$access_token = $row['access_token'];
		include_once('uninstallApp.php');
?>
		<html>
		<head>
			<!--Style-->
			<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600,700" rel="stylesheet">
			<link href="css/jquery-ui.css" rel="stylesheet" />
			<link href="css/bootstrap.min.css"  rel="stylesheet" type="text/css"/>  
			<link href="css/main.css" rel="stylesheet" type="text/css" />
			<!--Style-->
			<!--Script-->
			<script src="js/jquery.min.js"></script>
			<script src="js/jquery-ui.js"></script>
			<script src="js/bootstrap.min.js"></script>
			<script src="https://use.fontawesome.com/988a7dc35f.js"></script>
			<script src="//www.youtube.com/iframe_api"></script>
			<!--Script-->
		</head>
		<body>
		<div class="content-container">
			<div class="loader"><span>Loading..Please Wait</span></div>
			<div id="main-container" class="container">
				<div id="tabs">
					<ul>
						<li><a href="#settings">Settings</a></li>
						<li><a href="#faq">FAQ</a></li>
						<li><a href="#demo_video">Demo video</a></li>
						<li><a href="#contact_us">Contact us</a></li>
					</ul>
					<div id="settings">
						<?php include_once(__DIR__.'/files/settings.php'); ?>
					</div>
					<div id="faq">
						<?php include_once(__DIR__.'/files/Faq.html'); ?>
					</div>
					<div id="demo_video">
						<?php include_once(__DIR__.'/files/demoVideo.php'); ?>
					</div>
					<div id="contact_us">
						<?php include_once(__DIR__.'/files/contact.php'); ?>
					</div>
				</div>
				<div class="PixelPopup" style="display:none;">
					<div class="PixelPopup-inner">
						<a href="" class="popup_close"><i class="fa fa-times" aria-hidden="true"></i></a>
						<div class="popupForm"></div>
					</div>
				</div>
				<div class="view_demo_instruction" style="display:none;">
					<img src="images/instruction.png" />
				</div>
			</div>
		</div> 

		<script>
		/********Cookies Code Start********/
		function setCookie(cname, cvalue, exdays) {
			var d = new Date();
			d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
			var expires = "expires="+d.toUTCString();
			document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
		}

		function getCookie(cname) {
			var name = cname + "=";
			var ca = document.cookie.split(';');
			for(var i = 0; i < ca.length; i++) {
				var c = ca[i];
				while (c.charAt(0) == ' ') {
					c = c.substring(1);
				}
				if (c.indexOf(name) == 0) {
					return c.substring(name.length, c.length);
				}
			}
			return "";
		}

		function checkCookie() {
			var user = getCookie("username");
			if (user != "") {
				alert("Welcome again " + user);
			} else {
				user = prompt("Please enter your name:", "");
				if (user != "" && user != null) {
					setCookie("username", user, 365);
				}
			}
		}
		function deleteCookie(cname) {
			var d = new Date(); 
			d.setTime(d.getTime() - (1000*60*60*24)); 
			var expires = "expires=" + d.toGMTString(); 
			window.document.cookie = cname+"="+"; "+expires;
		 
		}
		/********Cookies Code End********/
		// On error Go to Main APP page
		function showLoader(shop,code,hmac,appurl) {
			$.ajax({
				url: '/removeShopData.php?shop='+shop,
				type: 'GET',
				success: function(response) {
					top.location.href = appurl+'appSetup.php?code='+code+'&hmac='+hmac+'&shop='+shop;
				}
			});
		}
		
		// Add ScriptTag API on load
		function addScript(access_token,shop) {
			$.ajax({
				url: '/addScript.php?access_token='+access_token+'&shop='+shop,
				type: 'GET',
				success: function(response) {
					//console.log(response);
				}
			});
		}
		
		// Add Customer Snippet on load
		function addCustomerSnippet(access_token,shop) {
			$.ajax({
				url: '/addCustomerSnippet.php?access_token='+access_token+'&shop='+shop,
				type: 'GET',
				success: function(response) {
					//console.log(response);
				}
			});
		}
		
		// GET Pixel Code on Load
		function getPixelCode(access_token,shop,code,hmac,appurl) {
			$.ajax({
				url: '/getPixelCode.php?access_token='+access_token+'&shop='+shop,
				type: 'GET',
				success: function(response) {
					if($.trim(response).indexOf("[401] Unauthorized") > -1) {
						showLoader(shop,code,hmac,appurl);
					} else {
						$(".loader").hide();
						if($.trim(response)) {
							$('.editPixelCode').html('');
							var pixelRows = JSON.parse(response);
							$.each(pixelRows, function(index,value) {
								var htmlPixel = '<tr><td><input class="form-control" type="text" name="pixelCode'+index+'" value="'+value+'" disabled /></td><td><a href="" class="edit_pixel" data-pixel-id="pixelCode'+index+'"><i class="fa fa-pencil" aria-hidden="true"></i></a><a href="" class="delete_pixel" data-pixel-id="pixelCode'+index+'"><i class="fa fa-trash" aria-hidden="true"></i></a></td></tr>';
								$('.editPixelCode').append(htmlPixel);
							});
							addScript(access_token,shop);
							addCustomerSnippet(access_token,shop);
						}
					}
				},
				complete: function() {
					$('#savepixel').val('ADD');
					$('.PixelPopup').hide();
				}
			});
		}
		
		// After Delete, Edited Pixel Code
		function editedPixel(access_token,shop) {
			$.ajax({
				url: '/editedPixel.php?access_token='+access_token+'&shop='+shop,
				type: 'GET',
				success: function(response) {
					if($.trim(response)) {
						//console.log(response);
						$('.editPixelCode').html('');
						var pixelRows = JSON.parse(response);
						$.each(pixelRows, function(index,value) {
							var htmlPixel = '<tr><td><input class="form-control" type="text" name="pixelCode'+index+'" value="'+value+'" disabled /></td><td><a href="" class="edit_pixel" data-pixel-id="pixelCode'+index+'"><i class="fa fa-pencil" aria-hidden="true"></i></a><a href="" class="delete_pixel" data-pixel-id="pixelCode'+index+'"><i class="fa fa-trash" aria-hidden="true"></i></a></td></tr>';
							$('.editPixelCode').append(htmlPixel);
						});
						if($('.editPixelCode tr').length) {
							var count = $('.editPixelCode tr').length;
							var pixelArr = {};
							$('.editPixelCode tr').each(function() {
								pixelArr[$('input',this).attr('name')] = $('input',this).val();
							});
							$.ajax({
								url: '/modifyPixelCode.php?access_token='+access_token+'&shop='+shop+'&count='+count,
								type: 'POST',
								data: pixelArr,
								success: function(response) {
									console.log(response);
								}
							});
						}
					}
				}
			});
		}

		$(document).ready(function(){
			$("#tabs").tabs();
			var icons = {
			  header: "ui-icon-plus",
			  activeHeader: "ui-icon-minus"
			};
			$( "#faq-accordion" ).accordion({
				collapsible: true,
				heightStyle: "content",
				icons: icons
			});
			var showVideo = getCookie('showVideo');
			if (showVideo != null && showVideo == 'showVideo') {
				$('.view_demo_instruction').show();
			}
			setTimeout(function() {
				$('.view_demo_instruction').hide();
				deleteCookie('showVideo');
			}, 2500);

			var access_token = '<?php echo $access_token ?>';
			var shop = '<?php echo $shop ?>';
			var code = '<?php echo $code ?>';
			var hmac = '<?php echo $hmac ?>';
			var appurl = '<?php echo $appurl ?>';
			
			// get Pixel Codes
			getPixelCode(access_token,shop,code,hmac,appurl);
			
			// Edit Pixel Code
			$('body').on('click', '.edit_pixel', function(e) {
				e.preventDefault();
				var pixelRow = $(this).data('pixel-id');
				$('input[name="'+pixelRow+'"]').attr('disabled',false);
			});
			
			$('body').on('click', '#saveEditPixel', function(e) {
				if($('.editPixelCode tr').length) {
					$('#saveEditPixel').val('Saving...');
					var count = $('.editPixelCode tr').length;
					var pixelArr = {};
					$('.editPixelCode tr').each(function() {
						pixelArr[$('input',this).attr('name')] = $('input',this).val();
					});
					$.ajax({
						url: '/editPixelCode.php?access_token='+access_token+'&shop='+shop+'&count='+count,
						type: 'POST',
						data: pixelArr,
						success: function(response) {
							//console.log(response);
						},
						complete: function() {
							$('#saveEditPixel').val('Save');
							$('.editPixelCode input').attr('disabled', true);
						}
					});
				}
			});
			// end Edit Pixel Code
			
			// Delete Pixel Code
			$('body').on('click', '.delete_pixel', function(e) {
				e.preventDefault();
				var _this = $(this);
				var pixelRow = $(this).data('pixel-id');
				$(this).html('<i class="fa fa-ellipsis-h" aria-hidden="true"></i>');
				$.ajax({
					url: '/deletePixelCode.php?access_token='+access_token+'&shop='+shop,
					type: 'POST',
					data: {'delPixelRow' : pixelRow},
					success: function(response) {
						_this.parents('tr').remove();
						editedPixel(access_token,shop);
					},
					complete: function() {
						_this.html('<i class="fa fa-trash" aria-hidden="true"></i>');
					}
				});
			});
			
			// Add New Pixel Code
			$('#addNewPixel').click(function(e){
				e.preventDefault();
				var count = 1;
				if($('.editPixelCode tr').length) {
					count = $('.editPixelCode tr').length + 1;
				}
				if(count > 5) {
					alert('You can add only 5 pixel IDs');
				} else {
					var newForm = '<form id="pixelSetting" name="pixelSetting"><h4 class="heading">Add new Pixel</h4><div class="form-group"><label for="pixelEditor">Pixel ID:</label><input class="form-control" name="pixelEditor" placeholder="XXXXXXXXX" id="pixelEditor" required /></div><input type="hidden" value="'+count+'" name="pixelCount" /><input type="submit" value="ADD" id="savepixel" class="btn btn-default" name="savepixel" /></form>';
					$('.popupForm').html(newForm);
					$('.PixelPopup').show();
				}
			});
			
			//Close Popup
			$('body').on('click', '.popup_close', function(e) {
				e.preventDefault();
				$('.PixelPopup').hide();
			});
			
			// Save New add Pixel Code
			$('body').on('submit', '#pixelSetting', function(e){
				e.preventDefault();
				$('#savepixel').val('ADDING...');
				var formData = $('#pixelSetting').serialize();
				console.log(formData);
				$.ajax({
					url: '/savePixelCode.php?access_token='+access_token+'&shop='+shop,
					type: 'GET',
					data: formData,
					success: function(response) {
						if(response.indexOf('Save Pixel Code') > -1) {
							$('#settings .alert-success').show().fadeOut(4000);
							addScript(access_token,shop);
						}
					}, 
					complete: function() {
						getPixelCode(access_token,shop,code,hmac,appurl);
					}
				});
			});
			
			// Send Email
			$('#sendEmail').click(function(e){
				if($('#firstname').val() != '' && $('#lastname').val() != '' && $('#email').val() != '' && $('#query').val() != '') {
					e.preventDefault();
					$('#contactUs .alert').hide();
					var formData = $('#contactUs').serialize();
					$.ajax({
						url: '/sendEmail.php?access_token='+access_token+'&shop='+shop,
						type: 'GET',
						data: formData,
						success: function(response) {
							if(response.indexOf('Sent') > -1) {
								$('#contact_us .alert-success').show().fadeOut(4000);
							} else {
								$('#contact_us .alert-danger').show().fadeOut(4000);
							}
						}
					});
				}
			});
			// End Send Email
		});
		$(document).ready(function() {
			/* var player;
			onYouTubeIframeAPIReady = function () {
				player = new YT.Player('video-instruction-iframe-main', {
					height: '80%',
					width: '100%',
					videoId: 'Nkg5yGdB_Gw',
					playerVars: {
						'autoplay': 1,
						'rel': 0,
						'showinfo': 0
					}
				});
			}
			$('#ytVideo_thumb').on('click', function() {
				$(this).hide();
				$('iframe#video-instruction-iframe-main').show();
				$('iframe#video-instruction-iframe-main').trigger('click');
				//player.playVideo();
			}); */
		});
		</script>

		</body>
		</html>
<?php
	}
}
?>