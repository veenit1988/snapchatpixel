<?php   
	define('SHOPIFY_APP_API_KEY', 'bbc6e12898eb39f2c7aed845733f2acb');
	define('SHOPIFY_APP_SHARED_SECRET', 'c9e2006be8a271373fd6a8cc5b3cd10a');
	define('APP_SERVER_URL','https://snapmultipixel.website/');
	define('SHOPIFY_REDIRECT_URL', APP_SERVER_URL.'appSetup.php');
    define('SHOPIFY_PURCHASE_RETURN_URL', APP_SERVER_URL.'payment.php');
	define('SHOPIFY_APP_NAME', 'Snaptrack - Multiple Snapchat Pixel Installer');
	define('SHOPIFY_APP_PRICE', '12.99');
	define('SHOPIFY_PURCHASE_MODE', false); //This is for Testing mode, If you don't want to use the testing mode, then false this Option
	define('SHOPIFY_TRIAL_DAYS', 3);
	define('SHOPIFY_APP_HANDLE', 'snapchat-pixel-installer-1');
	define('EMAIL_TO', 'optiapps.contact@gmail.com');
	define('EMAIL_SUBJECT', 'Snapctrack App Query');
?>
